# BHOP — Android video editor prototype

BHOP is an Android-native Kotlin + Jetpack Compose project. This update adds an editable multi-track clip timeline, trim/split/move operations, project save/load, undo/redo, and a Media3 export path.

## Implemented in this update

- AMOLED, Dark and Light themes
- Import video clips with Android's document picker
- Multiple video tracks (clips are assigned across the first two video tracks)
- Select clips and drag them horizontally to change timeline position
- Nudge clips by one second
- Trim a clip's beginning or end in 0.5-second increments
- Split a selected clip at the playhead
- Delete selected clips
- Undo and redo for clip/project edits
- Save and reopen `.bhop.json` project files through Android's system file picker
- Export the selected clip as MP4 using AndroidX Media3 Transformer

## Important export limitation

The current export action renders **the selected source clip with its trim range**. It does not yet composite every timeline track into one finished multi-layer movie. Timeline positions, overlapping layers, transitions, visual effects, audio mixing and keyframes are not yet included in the exported result. This is a functional first export path, not a complete Alight Motion replacement.

## Build the APK using only your Android phone

You do not need Android Studio or a laptop. GitHub Actions builds the APK on a cloud runner; your phone is only used to upload the project and download the APK.

### One-time setup

1. Create a repository on GitHub using your phone browser. Choose **Private** if you want the source code kept private.
2. Upload the file `BHOP-Android-Project-v0.2.zip` to the repository root and commit it. (The ZIP contains the full Android project.)
3. In the repository, choose **Add file → Create new file**.
4. For the filename, enter exactly `.github/workflows/android-apk.yml`.
5. Paste the workflow below into the editor, then commit it to the `main` branch:

```yaml
name: Build BHOP APK

on:
  workflow_dispatch:
  push:
    branches: [ main ]

permissions:
  contents: read

jobs:
  build:
    runs-on: ubuntu-latest
    steps:
      - name: Check out project
        uses: actions/checkout@v4
      - name: Unpack uploaded project archive
        shell: bash
        run: |
          if [ -f BHOP-Android-Project-v0.2.zip ]; then
            mkdir -p source
            unzip -q BHOP-Android-Project-v0.2.zip -d source
            echo "PROJECT_DIR=source/CarterMotionStudio" >> "$GITHUB_ENV"
          else
            echo "Project ZIP not found in repository root."
            exit 1
          fi
      - name: Set up JDK 17
        uses: actions/setup-java@v4
        with:
          distribution: temurin
          java-version: '17'
      - name: Set up Gradle
        uses: gradle/actions/setup-gradle@v4
        with:
          gradle-version: '8.9'
      - name: Build debug APK
        run: gradle -p "$PROJECT_DIR" :app:assembleDebug --no-daemon
      - name: Upload APK
        uses: actions/upload-artifact@v4
        with:
          name: BHOP-debug-apk
          path: ${{ env.PROJECT_DIR }}/app/build/outputs/apk/debug/app-debug.apk
          if-no-files-found: error
          retention-days: 14
```

### Build and install

1. Open the repository's **Actions** tab.
2. Select **Build BHOP APK**.
3. Tap **Run workflow**, leave `main` selected, and confirm.
4. Wait for the run to finish with a green check. Open that run and scroll to **Artifacts**.
5. Download `BHOP-debug-apk`. GitHub downloads it as a ZIP file.
6. Extract the downloaded ZIP using your phone's file manager. Find `app-debug.apk` inside it.
7. Tap `app-debug.apk` to install. Android may ask you to allow your browser or file manager to install apps from that source. Only enable this for the app you used to download the APK, then switch it off again afterward if you prefer.

If the workflow fails, open the run, expand the failed step, and share the first meaningful error text. Do not share account passwords, recovery codes, signing keys or private tokens.

## Build workflow details

The workflow uses JDK 17, Gradle 8.9 and `:app:assembleDebug`, then stores the debug APK as a downloadable artifact for 14 days. Each workflow run builds from the source currently committed to the repository.

## Technical requirements

- Android min SDK: 26
- Compile/target SDK: 35
- Kotlin: 2.0.21
- Android Gradle Plugin: 8.7.3
- Media3: 1.5.1
- JDK: 17

## Known limitations / next work

- Export currently handles one selected clip, not a full multi-track composition.
- The clip timeline supports horizontal dragging, basic trimming and splitting, but does not yet provide precision trim handles or pinch-to-zoom.
- The preview displays the selected source media, not a live composite of every layer.
- GPU effects, keyframe animation, transitions, audio waveform/mixing, autosave and a full multi-clip composition renderer remain future work.
- This source update has not been compiled or device-tested in this environment. The GitHub Actions run is the first real Android build verification.
