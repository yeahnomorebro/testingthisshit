package com.carter.motion

import android.content.Context
import android.net.Uri
import android.media.MediaMetadataRetriever
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.common.MediaItem
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import androidx.media3.transformer.EditedMediaItem
import androidx.media3.transformer.ExportException
import androidx.media3.transformer.ExportResult
import androidx.media3.transformer.Transformer
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.UUID

private data class UiPalette(val background: Color, val panel: Color, val panel2: Color, val accent: Color, val muted: Color, val text: Color)
private val AmoledPalette = UiPalette(Color.Black, Color(0xFF090909), Color(0xFF171717), Color(0xFFFF3658), Color(0xFF929292), Color(0xFFF5F5F5))
private val DarkPalette = UiPalette(Color(0xFF101116), Color(0xFF1B1D25), Color(0xFF292C37), Color(0xFFFF3B55), Color(0xFFA0A5B2), Color(0xFFF4F5F8))
private val LightPalette = UiPalette(Color(0xFFF3F4F7), Color.White, Color(0xFFE4E7ED), Color(0xFFD92748), Color(0xFF626978), Color(0xFF171923))
private val LocalPalette = androidx.compose.runtime.staticCompositionLocalOf { DarkPalette }

private data class EditClip(
    val id: String = UUID.randomUUID().toString(),
    val title: String,
    val uri: String,
    val track: Int = 0,
    val startMs: Long = 0,
    val sourceStartMs: Long = 0,
    val durationMs: Long = 10_000
)
private val trackNames = listOf("VIDEO 1", "VIDEO 2", "OVERLAY", "AUDIO")
private val trackColors = listOf(Color(0xFF3478F6), Color(0xFF8B63E8), Color(0xFF20B99B), Color(0xFFE6A23C))

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) { super.onCreate(savedInstanceState); setContent { EditorApp() } }
}

@Composable
private fun CarterTheme(palette: UiPalette, content: @Composable () -> Unit) {
    val scheme = if (palette == LightPalette) lightColorScheme(primary = palette.accent, background = palette.background, surface = palette.panel, onBackground = palette.text, onSurface = palette.text)
    else darkColorScheme(primary = palette.accent, background = palette.background, surface = palette.panel, onBackground = palette.text, onSurface = palette.text)
    androidx.compose.runtime.CompositionLocalProvider(LocalPalette provides palette) { MaterialTheme(colorScheme = scheme, content = content) }
}

@OptIn(UnstableApi::class)
@Composable
private fun EditorApp() {
    val context = androidx.compose.ui.platform.LocalContext.current
    var themeName by remember { mutableStateOf("AMOLED") }
    val palette = when (themeName) { "Dark" -> DarkPalette; "Light" -> LightPalette; else -> AmoledPalette }
    var clips by remember { mutableStateOf(listOf<EditClip>()) }
    var selectedId by remember { mutableStateOf<String?>(null) }
    var playhead by remember { mutableLongStateOf(0L) }
    var projectName by remember { mutableStateOf("Untitled Project") }
    var status by remember { mutableStateOf("Ready") }
    var busy by remember { mutableStateOf(false) }
    val undoStack = remember { mutableStateListOf<String>() }
    val redoStack = remember { mutableStateListOf<String>() }
    val selected = clips.firstOrNull { it.id == selectedId }

    fun snapshot(items: List<EditClip> = clips): String = encodeProject(projectName, items)
    fun recordUndo() { undoStack.add(snapshot()); if (undoStack.size > 40) undoStack.removeAt(0); redoStack.clear() }
    fun changeClips(next: List<EditClip>) { recordUndo(); clips = next }
    fun addMedia(uri: Uri) {
        runCatching { context.contentResolver.takePersistableUriPermission(uri, android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION) }
        val name = uri.lastPathSegment?.substringAfterLast('/')?.take(22) ?: "Video ${clips.size + 1}"
        val mediaDuration = runCatching {
            MediaMetadataRetriever().let { retriever ->
                try { retriever.setDataSource(context, uri); retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 10_000L }
                finally { retriever.release() }
            }
        }.getOrDefault(10_000L).coerceAtLeast(500L)
        val clip = EditClip(title = name, uri = uri.toString(), track = (clips.size % 2), startMs = clips.filter { it.track == 0 }.maxOfOrNull { it.startMs + it.durationMs } ?: 0L, durationMs = mediaDuration)
        changeClips(clips + clip); selectedId = clip.id; status = "Added $name"
    }

    val importPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri -> if (uri != null) addMedia(uri) }
    val loadPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) runCatching {
            val json = context.contentResolver.openInputStream(uri)!!.bufferedReader().use { it.readText() }
            val parsed = decodeProject(json)
            projectName = parsed.first; clips = parsed.second; selectedId = clips.firstOrNull()?.id; playhead = 0L; undoStack.clear(); redoStack.clear(); status = "Project loaded"
            clips.forEach { runCatching { context.contentResolver.takePersistableUriPermission(Uri.parse(it.uri), android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION) } }
        }.onFailure { status = "Could not open project: ${it.message}" }
    }
    val savePicker = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { uri ->
        if (uri != null) runCatching { context.contentResolver.openOutputStream(uri)!!.bufferedWriter().use { it.write(snapshot()) }; status = "Project saved" }
            .onFailure { status = "Save failed: ${it.message}" }
    }
    val exportPicker = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("video/mp4")) { destination ->
        val clip = selected
        if (destination != null && clip != null) {
            busy = true; status = "Preparing export…"
            val temp = File(context.cacheDir, "bhop-export-${System.currentTimeMillis()}.mp4")
            val media = MediaItem.Builder().setUri(Uri.parse(clip.uri)).setClippingConfiguration(
                MediaItem.ClippingConfiguration.Builder().setStartPositionMs(clip.sourceStartMs).setEndPositionMs(clip.sourceStartMs + clip.durationMs).build()
            ).build()
            val listener = object : Transformer.Listener {
                override fun onCompleted(composition: androidx.media3.transformer.Composition, exportResult: ExportResult) {
                    Thread {
                        runCatching {
                            context.contentResolver.openOutputStream(destination)?.use { out -> temp.inputStream().use { it.copyTo(out) } }
                        }.onSuccess { runOnUi(context) { status = "Export saved"; busy = false; temp.delete() } }
                         .onFailure { runOnUi(context) { status = "Export copy failed: ${it.message}"; busy = false; temp.delete() } }
                    }.start()
                }
                override fun onError(composition: androidx.media3.transformer.Composition, exportResult: ExportResult, exportException: ExportException) {
                    status = "Export failed: ${exportException.message}"; busy = false; temp.delete()
                }
            }
            runCatching { Transformer.Builder(context).addListener(listener).build().start(EditedMediaItem.Builder(media).build(), temp.absolutePath) }
                .onFailure { status = "Export could not start: ${it.message}"; busy = false }
        }
    }

    CarterTheme(palette) {
        Column(Modifier.fillMaxSize().background(palette.background)) {
            TopBar(projectName, { projectName = it }, { importPicker.launch(arrayOf("video/*")) }, themeName, { themeName = it }, palette,
                onSave = { savePicker.launch("${projectName.replace(Regex("[^A-Za-z0-9_-]"), "_")}.bhop.json") },
                onLoad = { loadPicker.launch(arrayOf("application/json", "text/*")) },
                onExport = { if (selected == null) status = "Select a video clip to export" else exportPicker.launch("${projectName.replace(Regex("[^A-Za-z0-9_-]"), "_")}.mp4") },
                onUndo = { if (undoStack.isNotEmpty()) { redoStack.add(snapshot()); val old = decodeProject(undoStack.removeAt(undoStack.lastIndex)); projectName = old.first; clips = old.second; selectedId = clips.firstOrNull()?.id; status = "Undo" } },
                onRedo = { if (redoStack.isNotEmpty()) { undoStack.add(snapshot()); val old = decodeProject(redoStack.removeAt(redoStack.lastIndex)); projectName = old.first; clips = old.second; selectedId = clips.firstOrNull()?.id; status = "Redo" } },
                canUndo = undoStack.isNotEmpty(), canRedo = redoStack.isNotEmpty(), busy = busy
            )
            PreviewArea(uri = selected?.let { Uri.parse(it.uri) }, status = status, busy = busy)
            TimelineEditor(clips, selectedId, playhead, { playhead = it }, { id -> selectedId = id }, { id, delta ->
                val item = clips.firstOrNull { it.id == id }
                if (item != null && delta != 0L) changeClips(clips.map { if (it.id == id) it.copy(startMs = (it.startMs + delta).coerceAtLeast(0)) else it })
            }, palette)
            ClipActions(selected, playhead, { delta ->
                selected?.let { c -> changeClips(clips.map { if (it.id == c.id) it.copy(startMs = (it.startMs + delta).coerceAtLeast(0)) else it }) }
            }, { edge ->
                selected?.let { c -> changeClips(clips.map { if (it.id == c.id) if (edge == "start") it.copy(sourceStartMs = (it.sourceStartMs + 500).coerceAtMost(it.sourceStartMs + it.durationMs - 500), durationMs = (it.durationMs - 500).coerceAtLeast(500), startMs = it.startMs + 500) else it.copy(durationMs = (it.durationMs - 500).coerceAtLeast(500)) else it }) }
            }, {
                selected?.let { c -> if (playhead > c.startMs && playhead < c.startMs + c.durationMs) {
                    val leftDuration = playhead - c.startMs
                    val right = c.copy(id = UUID.randomUUID().toString(), title = c.title + " (split)", startMs = playhead, sourceStartMs = c.sourceStartMs + leftDuration, durationMs = c.durationMs - leftDuration)
                    changeClips(clips.flatMap { if (it.id == c.id) listOf(it.copy(durationMs = leftDuration), right) else listOf(it) }); selectedId = right.id; status = "Clip split"
                } else status = "Move playhead inside the selected clip first" }
            }, { selected?.let { c -> changeClips(clips.filterNot { it.id == c.id }); selectedId = clips.firstOrNull { it.id != c.id }?.id; status = "Clip deleted" } }, palette)
            Text(status, color = palette.muted, fontSize = 10.sp, modifier = Modifier.fillMaxWidth().background(palette.panel).padding(horizontal = 12.dp, vertical = 5.dp))
        }
    }
}

private fun runOnUi(context: Context, action: () -> Unit) { (context as? ComponentActivity)?.runOnUiThread(action) }

private fun encodeProject(name: String, clips: List<EditClip>): String {
    val root = JSONObject().put("format", "bhop-project-v1").put("name", name)
    val array = JSONArray()
    clips.forEach { c -> array.put(JSONObject().put("id", c.id).put("title", c.title).put("uri", c.uri).put("track", c.track).put("startMs", c.startMs).put("sourceStartMs", c.sourceStartMs).put("durationMs", c.durationMs)) }
    return root.put("clips", array).toString(2)
}
private fun decodeProject(text: String): Pair<String, List<EditClip>> {
    val root = JSONObject(text); require(root.optString("format") == "bhop-project-v1") { "Not a BHOP project file" }
    val arr = root.getJSONArray("clips"); val clips = (0 until arr.length()).map { i -> val o = arr.getJSONObject(i); EditClip(o.getString("id"), o.getString("title"), o.getString("uri"), o.optInt("track").coerceIn(0, 3), o.optLong("startMs"), o.optLong("sourceStartMs"), o.optLong("durationMs", 10_000).coerceAtLeast(500)) }
    return root.optString("name", "Untitled Project") to clips
}

@Composable
private fun TopBar(projectName: String, onNameChange: (String) -> Unit, onImport: () -> Unit, themeName: String, onThemeChange: (String) -> Unit, palette: UiPalette,
                   onSave: () -> Unit, onLoad: () -> Unit, onExport: () -> Unit, onUndo: () -> Unit, onRedo: () -> Unit, canUndo: Boolean, canRedo: Boolean, busy: Boolean) {
    var editing by remember { mutableStateOf(false) }; var menu by remember { mutableStateOf(false) }
    Column(Modifier.fillMaxWidth().background(palette.panel)) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 10.dp, vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Default.Movie, null, tint = palette.accent, modifier = Modifier.size(28.dp)); Spacer(Modifier.width(8.dp))
            Column(Modifier.weight(1f)) { Text("BHOP", color = palette.text, fontWeight = FontWeight.Bold, fontSize = 13.sp); if (editing) TextField(projectName, onNameChange, singleLine = true) else Text(projectName, color = palette.muted, fontSize = 10.sp, modifier = Modifier.clickable { editing = true }) }
            IconButton(onClick = onUndo, enabled = canUndo) { Icon(Icons.Default.Undo, "Undo", tint = if (canUndo) palette.text else palette.muted) }
            IconButton(onClick = onRedo, enabled = canRedo) { Icon(Icons.Default.Redo, "Redo", tint = if (canRedo) palette.text else palette.muted) }
            Box { IconButton(onClick = { menu = true }) { Icon(Icons.Default.MoreVert, "Project menu", tint = palette.text) }; DropdownMenu(menu, { menu = false }) {
                DropdownMenuItem(text = { Text("Import video") }, onClick = { menu = false; onImport() })
                DropdownMenuItem(text = { Text("Save project") }, onClick = { menu = false; onSave() })
                DropdownMenuItem(text = { Text("Open project") }, onClick = { menu = false; onLoad() })
                listOf("AMOLED", "Dark", "Light").forEach { DropdownMenuItem(text = { Text("Theme: $it") }, onClick = { onThemeChange(it); menu = false }) }
            } }
            Button(onClick = onExport, enabled = !busy, contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp)) { Text(if (busy) "…" else "Export", fontSize = 11.sp) }
        }
    }
}

@Composable
private fun PreviewArea(uri: Uri?, status: String, busy: Boolean) {
    val palette = LocalPalette.current; val context = androidx.compose.ui.platform.LocalContext.current
    val player = remember(uri) { ExoPlayer.Builder(context).build().apply { if (uri != null) { setMediaItem(MediaItem.fromUri(uri)); prepare() } } }
    DisposableEffect(player) { onDispose { player.release() } }
    Column(Modifier.fillMaxWidth().padding(horizontal = 10.dp, vertical = 7.dp)) {
        Box(Modifier.fillMaxWidth().height(155.dp).clip(RoundedCornerShape(12.dp)).background(Color.Black), contentAlignment = Alignment.Center) {
            if (uri != null) AndroidView(factory = { PlayerView(it).apply { this.player = player; useController = true } }, modifier = Modifier.fillMaxSize())
            else Column(horizontalAlignment = Alignment.CenterHorizontally) { Icon(Icons.Default.VideoLibrary, null, tint = palette.muted, modifier = Modifier.size(34.dp)); Text("Import a video to begin", color = palette.text, fontSize = 12.sp) }
            if (busy) CircularProgressIndicator(Modifier.align(Alignment.Center), color = palette.accent)
        }
    }
}

@Composable
private fun TimelineEditor(clips: List<EditClip>, selectedId: String?, playhead: Long, onPlayhead: (Long) -> Unit, onSelect: (String) -> Unit, onMove: (String, Long) -> Unit, palette: UiPalette) {
    val scroll = rememberScrollState(); val pxPerSecond = 42.dp; val pxPerSecondPx = with(androidx.compose.ui.platform.LocalDensity.current) { pxPerSecond.toPx() }; val timelineWidth = 900.dp
    Column(Modifier.fillMaxWidth().weight(1f).background(palette.background).padding(top = 5.dp)) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 10.dp), horizontalArrangement = Arrangement.SpaceBetween) { Text("TIMELINE · ${clips.size} CLIPS", color = palette.text, fontWeight = FontWeight.Bold, fontSize = 11.sp); Text("Drag clips to move", color = palette.muted, fontSize = 9.sp) }
        Row(Modifier.fillMaxWidth().padding(start = 8.dp, top = 7.dp)) {
            Column(Modifier.width(72.dp)) { trackNames.forEachIndexed { i, name -> Box(Modifier.height(48.dp).fillMaxWidth().padding(end = 5.dp, bottom = 3.dp).clip(RoundedCornerShape(5.dp)).background(palette.panel), contentAlignment = Alignment.Center) { Text(name, color = palette.muted, fontSize = 8.sp) } } }
            Column(Modifier.weight(1f).horizontalScroll(scroll)) {
                Box(Modifier.width(timelineWidth).height(20.dp)) { (0..30 step 5).forEach { s -> Text("%02d:%02d".format(s / 60, s % 60), color = palette.muted, fontSize = 8.sp, modifier = Modifier.offset(x = pxPerSecond * s)) } }
                trackNames.forEachIndexed { track, _ ->
                    Box(Modifier.width(timelineWidth).height(48.dp).padding(bottom = 3.dp).clip(RoundedCornerShape(5.dp)).background(palette.panel2.copy(alpha = .55f))) {
                        clips.filter { it.track == track }.forEach { clip ->
                            val x = pxPerSecond * (clip.startMs / 1000f)
                            val w = (pxPerSecond * (clip.durationMs / 1000f)).coerceAtLeast(48.dp)
                            Box(Modifier.offset(x = x).width(w).height(44.dp).padding(2.dp).clip(RoundedCornerShape(5.dp))
                                .background(trackColors[track].copy(alpha = if (selectedId == clip.id) 1f else .72f))
                                .then(if (selectedId == clip.id) Modifier.border(2.dp, Color.White, RoundedCornerShape(5.dp)) else Modifier)
                                 .pointerInput(clip.id, scroll.value) {
                                    var accumulated = 0f
                                    detectDragGestures(onDragStart = { accumulated = 0f; onSelect(clip.id) }, onDragEnd = { onMove(clip.id, (accumulated / pxPerSecondPx * 1000).toLong()) }) { change, drag ->
                                        change.consume(); accumulated += drag.x
                                    }
                                }.clickable { onSelect(clip.id) }, contentAlignment = Alignment.CenterStart) {
                                Text(clip.title.take(16), color = Color.White, fontSize = 9.sp, maxLines = 1, modifier = Modifier.padding(horizontal = 5.dp))
                            }
                        }
                        Box(Modifier.offset(x = pxPerSecond * (playhead / 1000f)).width(2.dp).fillMaxHeight().background(palette.accent))
                    }
                }
                Spacer(Modifier.height(5.dp))
                Slider(value = (playhead / 30_000f).coerceIn(0f, 1f), onValueChange = { onPlayhead((it * 30_000).toLong()) }, modifier = Modifier.width(timelineWidth).height(25.dp), colors = SliderDefaults.colors(thumbColor = palette.accent, activeTrackColor = palette.accent))
            }
        }
    }
}

@Composable
private fun ClipActions(clip: EditClip?, playhead: Long, onNudge: (Long) -> Unit, onTrim: (String) -> Unit, onSplit: () -> Unit, onDelete: () -> Unit, palette: UiPalette) {
    Column(Modifier.fillMaxWidth().background(palette.panel).padding(horizontal = 9.dp, vertical = 6.dp)) {
        Text(clip?.let { "SELECTED: ${it.title}  ·  ${it.durationMs / 1000f}s" } ?: "Select a clip to edit", color = palette.muted, fontSize = 9.sp)
        Row(Modifier.horizontalScroll(rememberScrollState()), verticalAlignment = Alignment.CenterVertically) {
            SmallAction("−1s", { onNudge(-1000) }, clip != null); SmallAction("+1s", { onNudge(1000) }, clip != null)
            SmallAction("Trim start", { onTrim("start") }, clip != null); SmallAction("Trim end", { onTrim("end") }, clip != null)
            SmallAction("Split @ playhead", onSplit, clip != null); SmallAction("Delete", onDelete, clip != null)
        }
    }
}
@Composable private fun SmallAction(label: String, action: () -> Unit, enabled: Boolean) { TextButton(onClick = action, enabled = enabled, contentPadding = PaddingValues(horizontal = 7.dp, vertical = 3.dp)) { Text(label, fontSize = 9.sp) } }
